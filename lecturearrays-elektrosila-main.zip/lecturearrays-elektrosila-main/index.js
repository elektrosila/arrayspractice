export const getMonth = (rNum) => {
    const months = [
      "Январь",
      "Февраль",
      "Март",
      "Апрель",
      "Май",
      "Июнь",
      "Июль",
      "Август",
      "Сентябрь",
      "Октябрь",
      "Ноябрь",
      "Декабрь"
    ];
    return `Месяц ${months[rNum - 1]}`;
  };
  
  export function getTotalPrice([arr]) {
      let totalPrice = 0;
      for (let i = 0; i < arr.length; i += 1) {
        totalPrice += arr[i][0] + arr[i][2];
      }
      return totalPrice;
    }
    
  export const countDuplicates = (arr) => {
      const count = {};
      for (let i = 0; i < arr.length; i += 1) {
          if (count[arr[i]]) {
              count[arr[i]] = 1; 
          } else {
              count[arr[i]] += 1;
          }
      }
  return count;
  }
  
  export const uniqueItems = (arr) => {
      let acc =[];
      for (let i = 0; i < arr.length; i += 1){
      if (!acc.includes(arr[1])){
       acc.push(arr[1])
      }
      }
      return acc; 
  }